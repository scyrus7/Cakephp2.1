<?php
class LocationsController extends AppController {
	var $name = 'Locations';
//	var $components = array('Session');

	function index() {
//		$this->set('posts', $this->Post->find('all'));
	}


}	